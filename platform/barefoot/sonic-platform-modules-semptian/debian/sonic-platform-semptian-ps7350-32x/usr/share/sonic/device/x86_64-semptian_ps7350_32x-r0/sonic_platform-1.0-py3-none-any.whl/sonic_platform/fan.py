#############################################################################
# Celestica
#
# Module contains an implementation of SONiC Platform Base API and
# provides the fan status which are available in the platform
#
#############################################################################

from __future__ import division
import math
import os.path
import syslog

try:
    from sonic_platform_base.fan_base import FanBase
    from .helper import APIHelper
except ImportError as e:
    raise ImportError(str(e) + "- required module not found")

from sonic_py_common.logger import Logger
SYSLOG_IDENTIFIER = "fan"
logger = Logger(SYSLOG_IDENTIFIER)

def DBG_PRINT(str):
    syslog.openlog("FAN")
    syslog.syslog(syslog.LOG_INFO, str)
    syslog.closelog()



FAN_NAME_LIST = ["FAN-1F", "FAN-1R", "FAN-2F", "FAN-2R",
                 "FAN-3F", "FAN-3R", "FAN-4F", "FAN-4R", "FAN-5F", "FAN-5R"]
FAN_SPEED_TOLERANCE = 10
PSU_FAN_MAX_RPM = 11000
PSU_I2C_MAPPING = {
    0: {
        "num": 10,
        "addr": "5a"
    },
    1: {
        "num": 11,
        "addr": "5b"
    },
}
NULL_VAL = "N/A"

def get_hw_intf():
    cmd = "cat "
    cmd = cmd + '/proc/xc3200an_mg_cpld'

    cpld_info_pipe = os.popen(cmd)
    str_hw_intf=cpld_info_pipe.read()
    strs_tmp = str_hw_intf.split('\n')
    hw_intf_str = 'Hardware_inf'
    for str_tmp in strs_tmp:
        sensor = str_tmp.split(':')
        if sensor[0].find(hw_intf_str) >= 0:
            #print("Hardware_inf:%s" % sensor[1])
            if sensor[1].find("0xa") >= 0:
                cpld_info_pipe.close()
                #print("board type is ps7350.1")
                return 1
            elif sensor[1].find("0x1a") >= 0:
                cpld_info_pipe.close()
                #print("board type is ps7350.1")
                return 1                
            else:
                #print("board type is ps7350.2")
                cpld_info_pipe.close()
                return 0              
        
    cpld_info_pipe.close()
            
    return  0

def get_mg_cpld_hwmon_offset():
    sysfs = "cat "
    sysfs = sysfs + '/sys/class/hwmon/hwmon{0}/name'
    
    offset = 3
    cpld_name = 'xc3200an_mg_cpld'
    for index in range(0, 10):
        cmd=sysfs.format(index)
        ret = os.popen(cmd)
        adaptername=ret.read()
        
        #print("cmd:%s  adaptername:%s find result:%s" % (cmd, adaptername, adaptername.find(cpld_name)))
        
        if adaptername.find(cpld_name) >= 0:
            #print("get:%s  adaptername:%s" % (cmd, adaptername))
            offset = index 
            ret.close()       
            break
        else:
            ret.close()
            
    return  int(offset)  

def get_crps_hwmon_offset(psu_index):
    sysfs = "cat "
    sysfs = sysfs + '/sys/class/hwmon/hwmon{0}/name'
    
    offset = 3
    crps_base_name = 'cpld_i2c_crps_{0}'
    cpld_name = crps_base_name.format(psu_index)
    for index in range(0, 10):
        cmd=sysfs.format(index)
        ret = os.popen(cmd)
        adaptername=ret.read()
        
        #print("cmd:%s  adaptername:%s find result:%s" % (cmd, adaptername, adaptername.find(cpld_name)))
        
        if adaptername.find(cpld_name) >= 0:
            #print("get:%s  adaptername:%s" % (cmd, adaptername))
            offset = index 
            ret.close()       
            break
        else:
            ret.close()
            
    return  int(offset)

def get_fan_cpld_hwmon_offset():
    sysfs = "cat "
    sysfs = sysfs + '/sys/class/hwmon/hwmon{0}/name'
    
    offset = 3
    cpld_name = 'xc3200an_fan_cpld'
    for index in range(0, 10):
        cmd=sysfs.format(index)
        ret = os.popen(cmd)
        adaptername=ret.read()
        
        #print("cmd:%s  adaptername:%s find result:%s" % (cmd, adaptername, adaptername.find(cpld_name)))
        
        if adaptername.find(cpld_name) >= 0:
            #print("get:%s  adaptername:%s" % (cmd, adaptername))
            offset = index 
            ret.close()       
            break
        else:
            ret.close()
            
    return  int(offset)  



class Fan(FanBase):
    """Platform-specific Fan class"""

    def __init__(self, fan_tray_index, fan_index=0, is_psu_fan=False, psu_index=0):
        FanBase.__init__(self)
        self.fan_index = fan_index
        self._api_helper = APIHelper()
        self.fan_tray_index = fan_tray_index
        self.is_psu_fan = is_psu_fan
        
        self.fan_present_state = False
        
        self.hw_intf = get_hw_intf()
        
        mg_hwmon_index = get_mg_cpld_hwmon_offset()

        index = 0
        if self.hw_intf == 1:
            self.psu_start_index = 1
            fan_hwmon_index = get_fan_cpld_hwmon_offset()
            index = fan_hwmon_index
        else:
            self.psu_start_index = 1
            index = mg_hwmon_index
         
        
        path = '/sys/class/hwmon/hwmon{0}/'
        self.BASE_CPLD1_PATH = path.format(mg_hwmon_index)
        self.FAN_DATA_PATH = path.format(index)
        #DBG_PRINT("self.BASE_CPLD1_PATH:%s " % self.BASE_CPLD1_PATH)

        crps0_offset = get_crps_hwmon_offset(0)
        crps1_offset = get_crps_hwmon_offset(1)
        self.BASE_CRPS0_PATH = path.format(crps0_offset)
        self.BASE_CRPS1_PATH = path.format(crps1_offset)
        
        if self.is_psu_fan:
            self.psu_index = psu_index
            self.psu_i2c_num = PSU_I2C_MAPPING[self.psu_index]["num"]
            self.psu_i2c_addr = PSU_I2C_MAPPING[self.psu_index]["addr"]
 


    def __read_txt_file(self, file_path):
        try:
            reg_file = open(file_path, "r")
        except IOError as e:
            print("Error: unable to open file: %s" % str(e))
            return False
    
        data = reg_file.readline().rstrip()
        reg_file.close()
    
        return data


    def __write_txt_file(self, file_path, value):
        try:
            with open(file_path, 'w') as fd:
                fd.write(str(value))
        except Exception:
            return False
        return True

    def __search_file_by_name(self, directory, file_name):
        for dirpath, dirnames, files in os.walk(directory):
            for name in files:
                file_path = os.path.join(dirpath, name)
                if name in file_name:
                    return file_path
        return None
        
    def __get_bmc(self, data_str):
        cmd_str = '/usr/share/sonic/platform/plugins/ipmitool sensor reading ' + data_str
        bmc_pipe = os.popen(cmd_str)
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Psu get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor:%s" % sensor[1])
                if sensor[1].find("disable") >= 0:
                    bmc_pipe.close()
                    return 0
                else:
                    data = sensor[1].split( )
                    #print("### data:%s" % data[0]) 
                    bmc_pipe.close()
                    return int(data[0])                
        
        bmc_pipe.close()
        
        return 0 
        
    def __get_bmc_presence(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sdr')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Psu get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### __get_bmc_presence sensor[1]:%s" % sensor[1])
                #DBG_PRINT("### __get_bmc_presence data_str:%s sensor[1]:%s" % (data_str, sensor[1]))
                if sensor[1].find("disable") >= 0:
                    #print("### find disable") 
                    #DBG_PRINT("### find disable")
                    bmc_pipe.close()
                    return False                   
                elif sensor[1].find(" 0 RPM") >= 0:
                    #print("### find 0 RPM") 
                    #DBG_PRINT("### find 0 RPM")
                    bmc_pipe.close()
                    return False                     
                else:
                    #print("### not find disable") 
                    bmc_pipe.close()
                    return True                
        
        bmc_pipe.close()
        return True 

    def __get_bmc_status(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sdr')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        #print("!!!!!!!!!!!!!!Psu get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### __get_bmc_presence sensor[1]:%s" % sensor[1])
                if sensor[2].find("nr") >= 0:
                    bmc_pipe.close()
                    return False
                else:
                    #print("### not find disable")
                    bmc_pipe.close()
                    return True
        bmc_pipe.close()
        return True

    def __get_bmc_rpm(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sdr')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        #print("!!!!!!!!!!!!!!Psu get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                data = sensor[1].split( )
                bmc_pipe.close()
                return data[0]
        bmc_pipe.close()
        return NULL_VAL

    def get_psu_presence(self):  
        """
        Retrieves the presence of the PSU
        Returns:
            bool: True if PSU is present, False if not
        """ 
        presence = 0  
        psu_presence_path = self.BASE_CPLD1_PATH + "psu1_presence" 
      
        if self.psu_index == 0:    
            psu_presence_path = self.BASE_CPLD1_PATH + "psu1_presence"     
        elif self.psu_index == 1:
            psu_presence_path = self.BASE_CPLD1_PATH + "psu2_presence"                 
        else: 
            DBG_PRINT("unkown index[%s] for get_presence" % self.psu_index) 
            
    
        val = self.__read_txt_file(psu_presence_path)
    
            
        if val == "1":
            #DBG_PRINT(" return True get_presence for self.index:%s psu_presence_path:%s content:%s" % (self.index, psu_presence_path, val))
            return True        
        else: 
            #DBG_PRINT("return False get_presence for self.index:%s psu_presence_path:%s content:%s" % (self.index, psu_presence_path, val))        
            return False  


    def get_direction(self):
        """
        Retrieves the direction of fan
        Returns:
            A string, either FAN_DIRECTION_INTAKE or FAN_DIRECTION_EXHAUST
            depending on fan direction
        """
        #print("fan get_direction fan_tray_index:%s fan_index:%s" % (self.fan_tray_index, self.fan_index))
        if self.is_psu_fan:
            direction = self.FAN_DIRECTION_EXHAUST
            return direction
            
            
        if self.fan_index == 0: 
            direction = self.FAN_DIRECTION_INTAKE
        else:
            direction = self.FAN_DIRECTION_EXHAUST

        return direction

    def get_speed_by_bmc(self):
        """
        Retrieves the speed of fan as a percentage of full speed
        Returns:
            An integer, the percentage of full fan speed, in the range 0 (off)
                 to 100 (full speed)

        Note:
            speed = pwm_in/255*100
        """
        tmp = 0
        str_pwr_tmp = 'pwr{0}.fan.rpm'
        
        
        if self.is_psu_fan:
            str_pwr = str_pwr_tmp.format(self.psu_index + self.psu_start_index)   
            tmp = self.__get_bmc(str_pwr)  
            
            #print("fan get_speed psu_index:%s rpm:%s" % (self.psu_index, tmp))            
            speed=tmp
            return int(speed)     
            
            
        if self.fan_tray_index == 0:    
            if self.fan_index == 0:
                #in.fan0.rpm
                tmp = self.__get_bmc("in.fan0.rpm")
            else:
                #out.fan0.rpm
                tmp = self.__get_bmc("out.fan0.rpm")      
        elif self.fan_tray_index == 1:
            if self.fan_index == 0:
                #in.fan1.rpm
                tmp = self.__get_bmc("in.fan1.rpm")
            else:
                #out.fan1.rpm
                tmp = self.__get_bmc("out.fan1.rpm")  
        elif self.fan_tray_index == 2:
            if self.fan_index == 0:
                #in.fan2.rpm
                tmp = self.__get_bmc("in.fan2.rpm")
            else:
                #out.fan2.rpm
                tmp = self.__get_bmc("out.fan2.rpm") 
        elif self.fan_tray_index == 3:
            if self.fan_index == 0:
                #in.fan3.rpm
                tmp = self.__get_bmc("in.fan3.rpm")
            else:
                #out.fan3.rpm
                tmp = self.__get_bmc("out.fan2.rpm")                 
        else: 
            print("unkown fan_tray_index[%s] for get_speed" % self.fan_tray_index)    
      
        #print("fan get_speed fan_tray_index:%s fan_index:%s" % (self.fan_tray_index, self.fan_index))
        speed=tmp
        return int(speed)

    def get_speed_by_come(self):
        """
        Retrieves the presence of the FAN
        Returns:
            bool: True if FAN is present, False if not
        """
        #print("fan get_presence is_psu_fan:%s fan_tray_index:%s" % (self.is_psu_fan, self.fan_tray_index))

        #DBG_PRINT("!!!!!! get_speed for %s" % self.fan_tray_index)
        
        presence = 0  
        fan_speed_path = self.FAN_DATA_PATH + "fan1_input" 
        
        if self.is_psu_fan: 
            if self.psu_index == 0:
                psu_data_path = self.BASE_CRPS0_PATH + "fan_rpm" 
            else:
                psu_data_path = self.BASE_CRPS1_PATH + "fan_rpm"        
            
            val = self.__read_txt_file(psu_data_path)
            #DBG_PRINT(" get_speed for self.fan_tray_index:%s fan_speed_path:%s content:%s" % (self.fan_tray_index, fan_speed_path, val))        
            val_int=int(int(val)/100)
            val_tmp=str(val_int)
            return float(val_tmp)  



        if self.fan_tray_index == 0:    
            if self.fan_index == 0:
                #in.fan0.rpm
                fan_speed_path = self.FAN_DATA_PATH + "fan1_input" 
            else:
                #out.fan0.rpm
                fan_speed_path = self.FAN_DATA_PATH + "fan5_input"      
        elif self.fan_tray_index == 1:
            if self.fan_index == 0:
                #in.fan1.rpm
                fan_speed_path = self.FAN_DATA_PATH + "fan2_input" 
            else:
                #out.fan1.rpm
                fan_speed_path = self.FAN_DATA_PATH + "fan6_input" 
        elif self.fan_tray_index == 2:
            if self.fan_index == 0:
                #in.fan2.rpm
                fan_speed_path = self.FAN_DATA_PATH + "fan3_input"
            else:
                #out.fan2.rpm
                fan_speed_path = self.FAN_DATA_PATH + "fan7_input"
        elif self.fan_tray_index == 3:
            if self.fan_index == 0:
                #in.fan3.rpm
                fan_speed_path = self.FAN_DATA_PATH + "fan4_input"
            else:
                #out.fan3.rpm
                fan_speed_path = self.FAN_DATA_PATH + "fan8_input"                 
        else: 
            print("unkown fan_tray_index[%s] for get_speed" % self.fan_tray_index)   

        val = self.__read_txt_file(fan_speed_path)
        #DBG_PRINT(" get_speed for self.fan_tray_index:%s fan_speed_path:%s content:%s" % (self.fan_tray_index, fan_speed_path, val))        
        val_int=int(int(val)/1000)*1000
        val_tmp=str(val_int)
        return float(val_tmp)  

    def get_speed(self):
        if self.hw_intf == 1: 
            return self.get_speed_by_bmc()
        else:
            return self.get_speed_by_come()

    def get_target_speed_by_come(self):

   
        target_speed = self.get_speed_by_come()
        if target_speed == 0:
            return float(30000)
        else:
            return target_speed
 
    def get_target_speed_fixed(self):    
	    return float(25000)     
		
    def get_target_speed(self):
        """
        Retrieves the target (expected) speed of the fan
        Returns:
            An integer, the percentage of full fan speed, in the range 0 (off)
                 to 100 (full speed)

        Note:
            speed_pc = pwm_target/255*100

            0   : when PWM mode is use
            pwm : when pwm mode is not use
        """        

        return self.get_target_speed_fixed()

    def get_speed_tolerance(self):
        """
        Retrieves the speed tolerance of the fan
        Returns:
            An integer, the percentage of variance from target speed which is
                 considered tolerable
        """
        #target_speed * (1 + float(tolerance) / 100)   target_speed * (1 - float(tolerance) / 100)
        return float(80)
        

    def set_speed(self, speed):
        """
        Sets the fan speed
        Args:
            speed: An integer, the percentage of full fan speed to set fan to,
                   in the range 0 (off) to 100 (full speed)
        Returns:
            A boolean, True if speed is set successfully, False if not
        """

        return False

    def set_status_led(self, color):
        """
        Sets the state of the fan module status LED
        Args:
            color: A string representing the color with which to set the
                   fan module status LED
        Returns:
            bool: True if status LED state is set successfully, False if not
        """

        return False #Not supported


    def get_status_led(self):
        """
        Gets the state of the fan status LED
        Returns:
            A string, one of the predefined STATUS_LED_COLOR_* strings above
        """

        return 'NA'

    def get_name(self):
        """
        Retrieves the name of the device
            Returns:
            string: The name of the device
        """
        #print("fan get_name fan_tray_index:%s fan_index:%s" % (self.fan_tray_index, self.fan_index))
        fan_name = FAN_NAME_LIST[self.fan_tray_index*2 + self.fan_index] \
            if not self.is_psu_fan \
            else "PSU-{} FAN-{}".format(self.psu_index+1, self.fan_index+1)

        return fan_name

    def get_presence_by_bmc(self):
        """
        Retrieves the presence of the FAN
        Returns:
            bool: True if FAN is present, False if not
        """
        #print("fan get_presence is_psu_fan:%s fan_tray_index:%s" % (self.is_psu_fan, self.fan_tray_index))
        
        presence = 0  
        str_pwr_tmp = 'pwr{0}.fan.rpm'
        
        
        if self.is_psu_fan:
            str_pwr = str_pwr_tmp.format(self.psu_index + self.psu_start_index)   
            presence = self.__get_bmc_presence(str_pwr)  
            
            #print("#########fan get_presence psu_index:%s presence:%s" % (self.psu_index, presence))
            return presence    
        
        if self.fan_tray_index == 0:
            presence = self.__get_bmc_presence("in.fan0.rpm")
        elif self.fan_tray_index == 1:
            presence = self.__get_bmc_presence("in.fan1.rpm") 
        elif self.fan_tray_index == 2:
            presence = self.__get_bmc_presence("in.fan2.rpm")  
        elif self.fan_tray_index == 3:
            presence = self.__get_bmc_presence("in.fan3.rpm")            
        else: 
            print("unkown fan_tray_index[%s] for get_presence" % self.fan_tray_index)          
        
        #DBG_PRINT("fan_tray_index[%s] presence[%s]" % (self.fan_tray_index, presence)) 
        
        if  self.fan_present_state != presence:
            if  presence == False:        
                DBG_PRINT("fan module %s was removed (pre_state %s) " % (self.fan_tray_index+1, self.fan_present_state))
            else:
                DBG_PRINT("fan module %s was inserted (pre_state %s)" % (self.fan_tray_index+1, self.fan_present_state))
            
        self.fan_present_state = presence            
        return presence        

    def get_presence_by_come(self):
        """
        Retrieves the speed of fan as a percentage of full speed
        Returns:
            An integer, the percentage of full fan speed, in the range 0 (off)
                 to 100 (full speed)

        Note:
            speed = pwm_in/255*100
        """
        presence = 0  
        fan_speed_path = self.FAN_DATA_PATH + "fan1_presence" 

        if self.is_psu_fan: 
         
            return self.get_psu_presence()

            
            
        if self.fan_tray_index == 0:    
            fan_speed_path = self.FAN_DATA_PATH + "fan1_presence"     
        elif self.fan_tray_index == 1:
            fan_speed_path = self.FAN_DATA_PATH + "fan2_presence" 
        elif self.fan_tray_index == 2:
            fan_speed_path = self.FAN_DATA_PATH + "fan3_presence" 
        elif self.fan_tray_index == 3:
            fan_speed_path = self.FAN_DATA_PATH + "fan4_presence"                 
        else: 
            print("unkown fan_tray_index[%s] for get_presence" % self.fan_tray_index) 
            

        val = self.__read_txt_file(fan_speed_path)

            
        if val == "1":
            #DBG_PRINT(" return True get_presence for self.fan_tray_index:%s fan_speed_path:%s content:%s" % (self.fan_tray_index, fan_speed_path, val))
            return True        
        else: 
            #DBG_PRINT(" return False get_presence for self.fan_tray_index:%s fan_speed_path:%s content:%s" % (self.fan_tray_index, fan_speed_path, val))        
            return False

    def get_presence(self):
	    return self.get_presence_by_bmc()

    def get_model(self):
        """
        Retrieves the model number (or part number) of the device
        Returns:
            string: Model/part number of device
        """
        if self.is_psu_fan:
            return NULL_VAL

        model = NULL_VAL
        return model

    def get_serial(self):
        """
        Retrieves the serial number of the device
        Returns:
            string: Serial number of device
        """
        if self.is_psu_fan:
            return NULL_VAL

        serial = NULL_VAL
        return serial

    def get_status_by_bmc(self):
        """
        Retrieves the operational status of the device
        Returns:
            A boolean value, True if device is operating properly, False if not
        """
        status = 0
        if self.is_psu_fan:
            if self.psu_index == 0:
                status = self.__get_bmc_status("pwr1.fan.rpm")
            else:
                status = self.__get_bmc_status("pwr2.fan.rpm")
            #print("#########fan get_presence psu_index:%s status:%s" % (self.psu_index, status))
            return status
        if self.fan_tray_index == 0:
            status = self.__get_bmc_status("in.fan0.rpm")
        elif self.fan_tray_index == 1:
            status = self.__get_bmc_status("in.fan1.rpm")
        elif self.fan_tray_index == 2:
            status = self.__get_bmc_status("in.fan2.rpm")
        elif self.fan_tray_index == 3:
            status = self.__get_bmc_status("in.fan3.rpm")
        else:
            print("unkown fan_tray_index[%s] for get_status" % self.fan_tray_index)
        #print("fan_tray_index[%s] status[%s]" % (self.fan_tray_index, status))
        return status
        #return True

    def get_status(self):
        """
        Retrieves the operational status of the device
        Returns:
            A boolean value, True if device is operating properly, False if not
        """

        return self.get_presence()

    def get_rpm_by_bmc(self):
        """
        Retrieves the RPM of the device
        Returns:
            String, RPM
        """
        rpm = 0
        str_pwr_tmp = 'pwr{0}.fan.rpm'
           
        if self.is_psu_fan:
            str_pwr = str_pwr_tmp.format(self.psu_index + self.psu_start_index)
            rpm = self.__get_bmc_rpm(str_pwr)
            #print("#########fan get_rpm psu_index:%s rpm:%s" % (self.psu_index, rpm))
            return rpm
        if self.fan_tray_index == 0:
            if self.fan_index == 0:
                rpm = self.__get_bmc_rpm("in.fan0.rpm")
            else:
                rpm = self.__get_bmc_rpm("out.fan0.rpm")
        elif self.fan_tray_index == 1:
            if self.fan_index == 0:
                rpm = self.__get_bmc_rpm("in.fan1.rpm")
            else:
                rpm = self.__get_bmc_rpm("out.fan1.rpm")
        elif self.fan_tray_index == 2:
            if self.fan_index == 0:
                rpm = self.__get_bmc_rpm("in.fan2.rpm")
            else:
                rpm = self.__get_bmc_rpm("out.fan2.rpm")
        elif self.fan_tray_index == 3:
            if self.fan_index == 0:
                rpm = self.__get_bmc_rpm("in.fan3.rpm")
            else:
                rpm = self.__get_bmc_rpm("out.fan3.rpm")
        else:
            print("unkown fan_tray_index[%s] for get_status" % self.fan_tray_index)
            
        #print("fan_tray_index[%s] rpm[%s]" % (self.fan_tray_index, rpm))
        return rpm

    def get_rpm(self):
        """
        Retrieves the RPM of the device
        Returns:
            String, RPM
        """
        rpm = 0
        str_pwr_tmp = 'pwr{0}.fan.rpm'
          
        return rpm

    def get_position_in_parent(self):
        """
        Retrieves 1-based relative physical position in parent device.
        If the agent cannot determine the parent-relative position
        for some reason, or if the associated value of
        entPhysicalContainedIn is'0', then the value '-1' is returned
        Returns:
            integer: The 1-based relative physical position in parent device
            or -1 if cannot determine the position
        """
        return (self.fan_tray_index*2 + self.fan_index + 1) \
            if not self.is_psu_fan else (self.fan_index+1)

    def is_replaceable(self):
        """
        Indicate whether this device is replaceable.
        Returns:
            bool: True if it is replaceable.
        """
        return True if not self.is_psu_fan else False

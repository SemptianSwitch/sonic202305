import os
import os.path
import syslog

try:
    from sonic_platform_base.psu_base import PsuBase
    #from sonic_platform.fan import Fan
    from .helper import APIHelper
except ImportError as e:
    raise ImportError(str(e) + "- required module not found")


from sonic_py_common.logger import Logger
SYSLOG_IDENTIFIER = "psu"
logger = Logger(SYSLOG_IDENTIFIER)

def DBG_PRINT(str):
    syslog.openlog("PSU")
    syslog.syslog(syslog.LOG_INFO, str)
    syslog.closelog()

I2C_PATH ="/sys/bus/i2c/devices/{0}-00{1}/"

PSU_NAME_LIST = ["PSU-1", "PSU-2"]
PSU_NUM_FAN = [1, 1]
PSU_HWMON_I2C_MAPPING = {
    0: {
        "num": 9,
        "addr": "58"
    },
    1: {
        "num": 9,
        "addr": "59"
    },
}

PSU_CPLD_I2C_MAPPING = {
    0: {
        "num": 9,
        "addr": "50"
    },
    1: {
        "num": 9,
        "addr": "51"
    },
}

NOT_AVAILABLE = 'N/A'

def get_hw_intf():
    cmd = "cat "
    cmd = cmd + '/proc/xc3200an_mg_cpld'

    cpld_info_pipe = os.popen(cmd)
    str_hw_intf=cpld_info_pipe.read()
    strs_tmp = str_hw_intf.split('\n')
    hw_intf_str = 'Hardware_inf'
    for str_tmp in strs_tmp:
        sensor = str_tmp.split(':')
        if sensor[0].find(hw_intf_str) >= 0:
            #print("Hardware_inf:%s" % sensor[1])
            if sensor[1].find("0xa") >= 0:
                cpld_info_pipe.close()
                #print("board type is ps7350.1")
                return 1
            elif sensor[1].find("0x1a") >= 0:
                cpld_info_pipe.close()
                #print("board type is ps7350.1")
                return 1                
            else:
                #print("board type is ps7350.2")
                cpld_info_pipe.close()
                return 0              
        
    cpld_info_pipe.close()
            
    return  0

def get_mg_cpld_hwmon_offset():
    sysfs = "cat "
    sysfs = sysfs + '/sys/class/hwmon/hwmon{0}/name'
    
    offset = 3
    cpld_name = 'xc3200an_mg_cpld'
    for index in range(0, 10):
        cmd=sysfs.format(index)
        ret = os.popen(cmd)
        adaptername=ret.read()
        
        #print("cmd:%s  adaptername:%s find result:%s" % (cmd, adaptername, adaptername.find(cpld_name)))
        
        if adaptername.find(cpld_name) >= 0:
            #print("get:%s  adaptername:%s" % (cmd, adaptername))
            offset = index 
            ret.close()       
            break
        else:
            ret.close()
            
    return  int(offset) 

def get_crps_hwmon_offset(psu_index):
    sysfs = "cat "
    sysfs = sysfs + '/sys/class/hwmon/hwmon{0}/name'
    
    offset = 3
    crps_base_name = 'cpld_i2c_crps_{0}'
    cpld_name = crps_base_name.format(psu_index)
    for index in range(0, 10):
        cmd=sysfs.format(index)
        ret = os.popen(cmd)
        adaptername=ret.read()
        
        #print("cmd:%s  adaptername:%s find result:%s" % (cmd, adaptername, adaptername.find(cpld_name)))
        
        if adaptername.find(cpld_name) >= 0:
            #print("get:%s  adaptername:%s" % (cmd, adaptername))
            offset = index 
            ret.close()       
            break
        else:
            ret.close()
            
    return  int(offset)



class Psu(PsuBase):
    """Platform-specific Psu class"""

    def __init__(self, psu_index=0):
        PsuBase.__init__(self)
        self.index = psu_index
        self._api_helper = APIHelper()

        index = get_mg_cpld_hwmon_offset()        
        path = '/sys/class/hwmon/hwmon{0}/'
        self.BASE_CPLD1_PATH = path.format(index)
        #DBG_PRINT("self.BASE_CPLD1_PATH:%s " % self.BASE_CPLD1_PATH)        

        crps0_offset = get_crps_hwmon_offset(0)
        crps1_offset = get_crps_hwmon_offset(1)
        self.BASE_CRPS0_PATH = path.format(crps0_offset)
        self.BASE_CRPS1_PATH = path.format(crps1_offset)
        
        self.hw_intf = get_hw_intf()
        if self.hw_intf == 1:
            self.psu_start_index = 1
        else:
            self.psu_start_index = 1        
        
        self.first_reg = True
        self.i2c_num = PSU_HWMON_I2C_MAPPING[self.index]["num"]
        self.i2c_addr = PSU_HWMON_I2C_MAPPING[self.index]["addr"]
        self.hwmon_path = I2C_PATH.format(self.i2c_num, self.i2c_addr)

        self.i2c_num = PSU_CPLD_I2C_MAPPING[self.index]["num"]
        self.i2c_addr = PSU_CPLD_I2C_MAPPING[self.index]["addr"]
        self.cpld_path = I2C_PATH.format(self.i2c_num, self.i2c_addr)
        self.__initialize_fan()

        self.psu_present_state = False

    def __initialize_fan(self):
        from sonic_platform.fan import Fan
        for fan_index in range(0, PSU_NUM_FAN[self.index]):
            fan = Fan(fan_index, 0, is_psu_fan=True, psu_index=self.index)
            self._fan_list.append(fan)


    def __read_txt_file(self, file_path):
        try:
            reg_file = open(file_path, "r")
        except IOError as e:
            print("Error: unable to open file: %s" % str(e))
            return False
    
        data = reg_file.readline().rstrip()
        reg_file.close()
    
        return data

    def __get_bmc(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sdr')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Psu get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor:%s" % sensor[1])
                if sensor[1].find("disable") >= 0:
                    bmc_pipe.close()
                    return 0
                else:
                    data = sensor[1].split( )
                    #print("### data:%s" % data[0]) 
                    bmc_pipe.close()
                    return float(data[0])                
        
        bmc_pipe.close()
        
        return 0 

    def __get_bmc_low_threshold(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sensor')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor[6]:%s" % sensor[6])
                #data = sensor[1].split( )
                #print("### data:%s" % data[0]) 
                bmc_pipe.close()
                return float(sensor[6])                
        
        bmc_pipe.close()
        
        return 0  

    def __get_bmc_middle_threshold(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sensor')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor[6]:%s" % sensor[6])
                #data = sensor[1].split( )
                #print("### data:%s" % data[0]) 
                bmc_pipe.close()
                return float(sensor[6])                
        
        bmc_pipe.close()
        
        return 0 

    def __get_bmc_high_threshold(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sensor')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor[7]:%s" % sensor[7])
                #data = sensor[1].split( )
                #print("### data:%s" % data[0]) 
                bmc_pipe.close()
                return float(sensor[7])                
        
        bmc_pipe.close()
        
        return 0 

    def __get_bmc_presence(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sdr')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Psu get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### __get_bmc_presence sensor[1]:%s" % sensor[1])
                #DBG_PRINT("### __get_bmc_presence data_str:%s sensor[1]:%s" % (data_str, sensor[1]))
                if sensor[1].find("disable") >= 0:
                    #print("### find disable") 
                    #DBG_PRINT("### find disable")
                    bmc_pipe.close()
                    return False  
                    
                elif sensor[1].find(" 0 Volts") >= 0:
                    #print("### find disable") 
                    #DBG_PRINT("### find 0 Volts")
                    bmc_pipe.close()
                    return False                    
                else:
                    #print("### not find disable") 
                    bmc_pipe.close()
                    return True                
        
        bmc_pipe.close()
        
        return True 

    def __get_bmc_status(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sdr')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Psu get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor:%s" % sensor[1])
                if sensor[1].find("disable") >= 0:
                #print("### data:%s" % data[0]) 
                    bmc_pipe.close()
                    return False  
                else:
                    bmc_pipe.close()
                    return True                
        
        bmc_pipe.close()
        
        return True 
        
    def get_voltage_by_bmc(self):
        """
        Retrieves current PSU voltage output
        Returns:
            A float number, the output voltage in volts,
            e.g. 12.1
        """
        str_pwr_tmp = 'pwr{0}.vout'
        str_pwr = str_pwr_tmp.format(self.index + self.psu_start_index)
    
        temp = self.__get_bmc(str_pwr) # changed

        #print("##psu index[%s] vol[%s] for get_voltage" % (self.index, temp)) 
        
        return  temp         
        
        vout_path = "{}{}".format(self.hwmon_path, 'psu_v_out')        
        vout_val=self._api_helper.read_txt_file(vout_path)
        if vout_val is not None:
            return float(vout_val)/ 1000
        else:
            return 0

    def get_current_by_bmc(self):
        """
        Retrieves present electric current supplied by PSU
        Returns:
            A float number, the electric current in amperes, e.g 15.4
        """
        
        str_pwr_tmp = 'pwr{0}.iout'
        str_pwr = str_pwr_tmp.format(self.index + self.psu_start_index)
    
        temp = self.__get_bmc(str_pwr) # changed  

        #print("##psu index[%s] current[%s]" % (self.index, temp)) 
        
        return  temp           

    def get_voltage(self):
        """
        Retrieves current PSU voltage output
        Returns:
            A float number, the output voltage in volts,
            e.g. 12.1
        """

        psu_data_path = self.BASE_CRPS0_PATH + "voltage_output" 
      
        if self.index == 0:    
            psu_data_path = self.BASE_CRPS0_PATH + "voltage_output"     
        elif self.index == 1:
            psu_data_path = self.BASE_CRPS1_PATH + "voltage_output"                 
        else: 
            print("unkown index[%s] for get_presence" % self.index) 
            
        if self.get_presence():
            val = self.__read_txt_file(psu_data_path)
            #DBG_PRINT("get_voltage for self.index:%s psu_data_path:%s val:%s" % (self.index, psu_data_path, val))        
            return float(val)/1000
        else:    
            return float(0)

    def get_input_voltage(self):
        """
        Retrieves current PSU voltage output
        Returns:
            A float number, the output voltage in volts,
            e.g. 12.1
        """

        psu_data_path = self.BASE_CRPS0_PATH + "voltage_input" 
      
        if self.index == 0:    
            psu_data_path = self.BASE_CRPS0_PATH + "voltage_input"     
        elif self.index == 1:
            psu_data_path = self.BASE_CRPS1_PATH + "voltage_input"                 
        else: 
            print("unkown index[%s] for get_presence" % self.index) 
            
        if self.get_presence():
            val = self.__read_txt_file(psu_data_path)
            #DBG_PRINT("get_voltage for self.index:%s psu_data_path:%s val:%s" % (self.index, psu_data_path, val)) 
            return float(val)/1000
        else:
            return float(0)


    def get_current(self):
        """
        Retrieves present electric current supplied by PSU
        Returns:
            A float number, the electric current in amperes, e.g 15.4
        """
        
        psu_data_path = self.BASE_CRPS0_PATH + "current_output" 
      
        if self.index == 0:    
            psu_data_path = self.BASE_CRPS0_PATH + "current_output"     
        elif self.index == 1:
            psu_data_path = self.BASE_CRPS1_PATH + "current_output"                 
        else: 
            print("unkown index[%s] for get_presence" % self.index) 
            

        if self.get_presence():
            val = self.__read_txt_file(psu_data_path)
            #DBG_PRINT("get_current for self.index:%s psu_data_path:%s val:%s" % (self.index, psu_data_path, val))          
            return float(val)/1000  
        else:
            return float(0)
        

    def get_input_current(self):
        """
        Retrieves present electric current supplied by PSU
        Returns:
            A float number, the electric current in amperes, e.g 15.4
        """
        
        psu_data_path = self.BASE_CRPS0_PATH + "current_input" 
      
        if self.index == 0:    
            psu_data_path = self.BASE_CRPS0_PATH + "current_input"     
        elif self.index == 1:
            psu_data_path = self.BASE_CRPS1_PATH + "current_input"                 
        else: 
            print("unkown index[%s] for get_presence" % self.index) 
            

        if self.get_presence():
            val = self.__read_txt_file(psu_data_path)
            #DBG_PRINT("get_current for self.index:%s psu_data_path:%s val:%s" % (self.index, psu_data_path, val))      
            return float(val)/1000        
        else:
            return float(0)
         

    def get_input_power(self):
        """
        Retrieves current energy supplied by PSU
        Returns:
            A float number, the power in watts, e.g. 302.6
        """
        
        temp = self.get_input_voltage() * self.get_input_current()        
        return  temp          
        

    def get_power(self):
        """
        Retrieves current energy supplied by PSU
        Returns:
            A float number, the power in watts, e.g. 302.6
        """
        
        temp = self.get_voltage() * self.get_current()        
        return  temp  

    def get_powergood_status(self):
        """
        Retrieves the powergood status of PSU
        Returns:
            A boolean, True if PSU has stablized its output voltages and passed all
            its internal self-tests, False if not.
        """
        return self.get_status()

    def set_status_led(self, color):
        """
        Sets the state of the PSU status LED
        Args:
            color: A string representing the color with which to set the PSU status LED
                   Note: Only support green and off
        Returns:
            bool: True if status LED state is set successfully, False if not
        """

        return NOT_AVAILABLE  #Controlled by HW

    def get_status_led(self):
        """
        Gets the state of the PSU status LED
        Returns:
            A string, one of the predefined STATUS_LED_COLOR_* strings above
        """

        return NOT_AVAILABLE  #Controlled by HW

    def get_temperature_by_bmc(self):
        """
        Retrieves current temperature reading from PSU
        Returns:
            A float number of current temperature in Celsius up to nearest thousandth
            of one degree Celsius, e.g. 30.125 
        """

        str_pwr_tmp = 'pwr{0}.tmp'
        str_pwr = str_pwr_tmp.format(self.index + self.psu_start_index)
    
        temp = self.__get_bmc(str_pwr) # changed     

        #print("##psu index[%s] get_temperature[%s] str_pwr[%s]" % (self.index, temp, str_pwr)) 
        
        return  temp          
       

    def get_temperature_high_threshold_by_bmc(self):
        """
        Retrieves the high threshold temperature of PSU
        Returns:
            A float number, the high threshold temperature of PSU in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """
        
        str_pwr_tmp = 'pwr{0}.tmp'
        str_pwr = str_pwr_tmp.format(self.index + self.psu_start_index)
    
        temp = self.__get_bmc_high_threshold(str_pwr) # changed  
        
        
        return  temp          


    def get_voltage_high_threshold_by_bmc(self):
        """
        Retrieves the high threshold PSU voltage output
        Returns:
            A float number, the high threshold output voltage in volts, 
            e.g. 12.1 
        """
        str_pwr_tmp = 'pwr{0}.vout'
        str_pwr = str_pwr_tmp.format(self.index + self.psu_start_index)
    
        temp = self.__get_bmc_high_threshold(str_pwr) # changed  


        #print("##psu index[%s] vol[%s] for get_voltage" % (self.index, temp)) 
        
        return  temp          

    def get_voltage_low_threshold_by_bmc(self):
        """
        Retrieves the low threshold PSU voltage output
        Returns:
            A float number, the low threshold output voltage in volts, 
            e.g. 12.1 
        """
        str_pwr_tmp = 'pwr{0}.vout'
        str_pwr = str_pwr_tmp.format(self.index + self.psu_start_index)
    
        temp = self.__get_bmc_low_threshold(str_pwr) # changed         

        #print("##psu index[%s] vol[%s] for get_voltage" % (self.index, temp)) 
        
        return  temp              

    def get_temperature(self):
        """
        Retrieves current temperature reading from PSU
        Returns:
            A float number of current temperature in Celsius up to nearest thousandth
            of one degree Celsius, e.g. 30.125 
        """

        return NOT_AVAILABLE #Not supported


    def get_temperature_high_threshold(self):
        """
        Retrieves the high threshold temperature of PSU
        Returns:
            A float number, the high threshold temperature of PSU in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """
        
        
        return NOT_AVAILABLE #Not supported

    def get_voltage_high_threshold(self):
        """
        Retrieves the high threshold PSU voltage output
        Returns:
            A float number, the high threshold output voltage in volts, 
            e.g. 12.1 
        """
        return float(14)        

    def get_voltage_low_threshold(self):
        """
        Retrieves the low threshold PSU voltage output
        Returns:
            A float number, the low threshold output voltage in volts, 
            e.g. 12.1 
        """
        return float(10)        

    def get_name(self):
        """
        Retrieves the name of the device
            Returns:
            string: The name of the device
        """
        return PSU_NAME_LIST[self.index]

    def get_presence_by_bmc(self):  
        """
        Retrieves the presence of the PSU
        Returns:
            bool: True if PSU is present, False if not
        """ 
        
        str_pwr_tmp = 'pwr{0}.vout'
        str_pwr = str_pwr_tmp.format(self.index + self.psu_start_index)
    
        temp = self.__get_bmc_presence(str_pwr) # changed

        if  self.psu_present_state != temp:
            if  temp == False:        
                DBG_PRINT("psu module %s was removed (pre_state %s) " % (self.index+1, self.psu_present_state))
            else:
                DBG_PRINT("psu module %s was inserted (pre_state %s)" % (self.index+1, self.psu_present_state))
            
        self.psu_present_state = temp    
        #DBG_PRINT("psu index[%s] presence[%s]" % (self.index, temp))  
        return temp
        
        presence_path="{}{}".format(self.cpld_path, 'psu_present')
        val=self._api_helper.read_txt_file(presence_path)
        if val is not None:
            return int(val, 10) == 1
        else:
            return 0

    def get_presence(self):  
        """
        Retrieves the presence of the PSU
        Returns:
            bool: True if PSU is present, False if not
        """ 
        presence = 0  
        psu_presence_path = self.BASE_CPLD1_PATH + "psu1_presence" 
      
        if self.index == 0:    
            psu_presence_path = self.BASE_CPLD1_PATH + "psu1_presence"     
        elif self.index == 1:
            psu_presence_path = self.BASE_CPLD1_PATH + "psu2_presence"                 
        else: 
            print("unkown index[%s] for get_presence" % self.index) 
            

        val = self.__read_txt_file(psu_presence_path)

            
        if val == "1":
            #DBG_PRINT(" return True get_presence for self.index:%s psu_presence_path:%s content:%s" % (self.index, psu_presence_path, val))
            return True        
        else: 
            #DBG_PRINT("return False get_presence for self.index:%s psu_presence_path:%s content:%s" % (self.index, psu_presence_path, val))        
            return False        


    def get_status(self):
        """
        Retrieves the operational status of the device
        Returns:
            A boolean value, True if device is operating properly, False if not
        """
        
        status = 0
        
        if (self.get_voltage() == 0 or self.get_current() == 0 or self.get_power() == 0):
            status = False
        else:
            status = True
        
        
        #print("psu index[%s] status[%s]" % (self.index, status))  
        return status

    
    def is_replaceable(self):
        """
        Indicate whether this device is replaceable.
        Returns:
            bool: True if it is replaceable.
        """
        return True
    
    def get_model(self):
        """
        Indicate whether this device is replaceable.
        Returns:
            bool: True if it is replaceable.
        """
        return NOT_AVAILABLE
    
    def get_serial(self):
        """
        Indicate whether this device is replaceable.
        Returns:
            bool: True if it is replaceable.
        """
        return NOT_AVAILABLE
    
    def get_revision(self):
        """
        Indicate whether this device is replaceable.
        Returns:
            bool: True if it is replaceable.
        """
        return NOT_AVAILABLE

#############################################################################
# Accton
#
# Thermal contains an implementation of SONiC Platform Base API and
# provides the thermal device status which are available in the platform
#
#############################################################################

import os
import os.path
import glob
import syslog

try:
    from sonic_platform_base.thermal_base import ThermalBase
except ImportError as e:
    raise ImportError(str(e) + "- required module not found")

def DBG_PRINT(str):
    syslog.openlog("THERMAL")
    syslog.syslog(syslog.LOG_INFO, str)
    syslog.closelog()

def get_hw_intf():
    cmd = "cat "
    cmd = cmd + '/proc/xc3200an_mg_cpld'

    cpld_info_pipe = os.popen(cmd)
    str_hw_intf=cpld_info_pipe.read()
    strs_tmp = str_hw_intf.split('\n')
    hw_intf_str = 'Hardware_inf'
    for str_tmp in strs_tmp:
        sensor = str_tmp.split(':')
        if sensor[0].find(hw_intf_str) >= 0:
            #print("Hardware_inf:%s" % sensor[1])
            if sensor[1].find("0xa") >= 0:
                cpld_info_pipe.close()
                #print("board type is ps7350.1")
                return 1
            elif sensor[1].find("0x1a") >= 0:
                cpld_info_pipe.close()
                #print("board type is ps7350.1")
                return 1                
            else:
                #print("board type is ps7350.2")
                cpld_info_pipe.close()
                return 0              
        
    cpld_info_pipe.close()
            
    return  0

def get_mg_cpld_hwmon_offset():
    sysfs = "cat "
    sysfs = sysfs + '/sys/class/hwmon/hwmon{0}/name'
    
    offset = 3
    cpld_name = 'xc3200an_mg_cpld'
    for index in range(0, 10):
        cmd=sysfs.format(index)
        ret = os.popen(cmd)
        adaptername=ret.read()
        
        #print("cmd:%s  adaptername:%s find result:%s" % (cmd, adaptername, adaptername.find(cpld_name)))
        
        if adaptername.find(cpld_name) >= 0:
            #print("get:%s  adaptername:%s" % (cmd, adaptername))
            offset = index 
            ret.close()       
            break
        else:
            ret.close()
            
    return  int(offset)

def get_crps_hwmon_offset(psu_index):
    sysfs = "cat "
    sysfs = sysfs + '/sys/class/hwmon/hwmon{0}/name'
    
    offset = 3
    crps_base_name = 'cpld_i2c_crps_{0}'
    cpld_name = crps_base_name.format(psu_index)
    for index in range(0, 10):
        cmd=sysfs.format(index)
        ret = os.popen(cmd)
        adaptername=ret.read()
        
        #print("cmd:%s  adaptername:%s find result:%s" % (cmd, adaptername, adaptername.find(cpld_name)))
        
        if adaptername.find(cpld_name) >= 0:
            #print("get:%s  adaptername:%s" % (cmd, adaptername))
            offset = index 
            ret.close()       
            break
        else:
            ret.close()
            
    return  int(offset)
    
threshold_dict = { 'mb_air.in.tmp0' : [0, 5, 10, 80, 85, 90] , 
              'mb_air.out.tmp0' : [0, 5, 10, 80, 85, 90],
              'mb_tmp411.bf.tmp' : [0, 5, 10, 95, 100, 105],
              'pwr1.tmp' : [0, 5, 10, 75, 80, 85],
              'pwr2.tmp' : [0, 5, 10, 75, 80, 85]}

class Thermal(ThermalBase):
    """Platform-specific Thermal class"""

    THERMAL_NAME_LIST = []
    SYSFS_PATH = "/sys/bus/i2c/devices"
    NOT_AVAILABLE = 'N/A'

    def __init__(self, thermal_index=0):
        self.THERMAL_NAME_LIST = []
        self.SYSFS_PATH = "/sys/bus/i2c/devices"
        self.index = thermal_index
        
        self.hw_intf = get_hw_intf()
        if self.hw_intf == 1:
            self.psu_start_index = 1
        else:
            self.psu_start_index = 1
            
        # Add thermal name
        self.THERMAL_NAME_LIST.append("Fan Front Temp")
        self.THERMAL_NAME_LIST.append("Fan Rear Temp")
        self.THERMAL_NAME_LIST.append("Switch Temp")        
        self.THERMAL_NAME_LIST.append("Psu 0 Temp")       
        self.THERMAL_NAME_LIST.append("Psu 1 Temp")      
        self.THERMAL_NAME_LIST.append("CPU Physical id 0 Temp")
        self.THERMAL_NAME_LIST.append("CPU Core 0 Temp")
        self.THERMAL_NAME_LIST.append("CPU Core 1 Temp")

        self.hwmon_path = "/sys/class/hwmon/hwmon0/"
 
        index = get_mg_cpld_hwmon_offset()        
        path = '/sys/class/hwmon/hwmon{0}/'
        self.BASE_CPLD1_PATH = path.format(index)
        #DBG_PRINT("self.BASE_CPLD1_PATH:%s " % self.BASE_CPLD1_PATH)        

        crps0_offset = get_crps_hwmon_offset(0)
        crps1_offset = get_crps_hwmon_offset(1)
        self.BASE_CRPS0_PATH = path.format(crps0_offset)
        self.BASE_CRPS1_PATH = path.format(crps1_offset)

    def __read_txt_file(self, file_path):
        for filename in glob.glob(file_path):
            try:
                with open(filename, 'r') as fd:                    
                    data =fd.readline().rstrip()
                    return data
            except IOError as e:
                pass

        return None

    def __get_temp(self, temp_file):
        temp_file_path = os.path.join(self.hwmon_path, temp_file)
        raw_temp = self.__read_txt_file(temp_file_path)
        if raw_temp is not None:
            return float(raw_temp)/1000
        else:
            return 0        

    def __get_bmc(self, data_str):
        cmd_str = '/usr/share/sonic/platform/plugins/ipmitool sensor reading ' + data_str
        bmc_pipe = os.popen(cmd_str)
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor:%s" % sensor[1])
                data = sensor[1].split( )
                #print("### data:%s" % data[0]) 
                bmc_pipe.close()
                return int(data[0])                
        
        bmc_pipe.close()
        
        return 0          

    def __get_bmc_high_threshold(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sensor')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor[7]:%s" % sensor[7])
                #data = sensor[1].split( )
                #print("### data:%s" % data[0]) 
                bmc_pipe.close()
                if sensor[7].strip() == 'na':
                    return self.NOT_AVAILABLE
                return float(sensor[7])                
        
        bmc_pipe.close()
        
        return 0   

    def __get_bmc_low_threshold(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sensor')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)

        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)

        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor[7]:%s" % sensor[7])
                #data = sensor[1].split( )
                #print("### data:%s" % data[0])
                bmc_pipe.close()
                if sensor[6].strip() == 'na':
                    return self.NOT_AVAILABLE
                return float(sensor[6])
				
        bmc_pipe.close()

        return 0

    def __get_bmc_high_critical_threshold(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sensor')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)

        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)

        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("####### sensor[9]:%s" % sensor[9])
                #data = sensor[1].split( )
                #print("### data:%s" % data[0])
                bmc_pipe.close()
                if sensor[9].strip() == 'na':
                    return self.NOT_AVAILABLE
                return float(sensor[9].strip())

        bmc_pipe.close()

        return 0

    def __get_bmc_low_critical_threshold(self, data_str):
        bmc_pipe = os.popen('/usr/share/sonic/platform/plugins/ipmitool sensor')
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)

        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)

        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor[7]:%s" % sensor[7])
                #data = sensor[1].split( )
                #print("### data:%s" % data[0])
                bmc_pipe.close()
                if sensor[4].strip() == 'na':
                    return self.NOT_AVAILABLE
                return float(sensor[4])
        bmc_pipe.close()

        return 0

    def __get_bmc(self, data_str):
        cmd_str = '/usr/share/sonic/platform/plugins/ipmitool sensor reading ' + data_str
        bmc_pipe = os.popen(cmd_str)
        str_bmc = bmc_pipe.read()
        #print("##########get str_bmc:%s" % str_bmc)
        
        #print("!!!!!!!!!!!!!!Thermal get str_bmc data_str:%s!!!!!!!!!!!!!!!!" % data_str)
        
        #print (str_bmc.split('\n'))
        strs_tmp = str_bmc.split('\n')
        for str_tmp in strs_tmp:
            sensor = str_tmp.split('|')
            if sensor[0].find(data_str) >= 0:
                #print("### sensor:%s" % sensor[1])
                data = sensor[1].split( )
                #print("### data:%s" % data[0]) 
                bmc_pipe.close()
                return int(data[0])                
        
        bmc_pipe.close()
        
        return 0  
        
    def __set_threshold(self, file_name, temperature):
        temp_file_path = os.path.join(self.hwmon_path, file_name)
        for filename in glob.glob(temp_file_path):
            try:
                with open(filename, 'w') as fd:
                    fd.write(str(temperature))
                return True
            except IOError as e:
                print("IOError")


    def get_temperature_by_bmc(self):
        """
        Retrieves current temperature reading from thermal
        Returns:
            A float number of current temperature in Celsius up to nearest thousandth
            of one degree Celsius, e.g. 30.125
        """
        
     
        temp = 0
        
        if self.index == 0:
            temp = self.__get_bmc("mb_air.in.tmp0")
        elif self.index == 1:
            temp = self.__get_bmc("mb_air.out.tmp0")
        elif self.index == 2:
            temp = self.__get_bmc("mb_tmp411.bf.tmp")
        elif self.index == 3:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc(str_tmp)  
        elif self.index == 4:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc(str_tmp)  
        elif self.index == 5:
            temp = self.__get_temp("temp1_input")  
        elif self.index == 6:
            temp = self.__get_temp("temp2_input") 
        elif self.index == 7:
            temp = self.__get_temp("temp3_input")           
            



        #print("#########thermal get_temperature temp:%s index:%s" % (temp, self.index))
        return temp
        

    def get_high_threshold_by_bmc(self):
        """
        Retrieves the high threshold temperature of thermal
        Returns:
            A float number, the high threshold temperature of thermal in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """

        temp = 0
        if self.index == 0:
            temp = self.__get_bmc_high_threshold("mb_air.in.tmp0")
        elif self.index == 1:
            temp = self.__get_bmc_high_threshold("mb_air.out.tmp0")
        elif self.index == 2:
            temp = self.__get_bmc_high_threshold("mb_tmp411.bf.tmp")
        elif self.index == 3:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc_high_threshold(str_tmp)        
        elif self.index == 4:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc_high_threshold(str_tmp)  
        elif self.index == 5:
            temp = self.__get_temp("temp1_max")  
        elif self.index == 6:
            temp = self.__get_temp("temp2_max") 
        elif self.index == 7:
            temp = self.__get_temp("temp3_max") 
            
        #print("#########thermal get_high_threshold temp:%s index:%s" % (temp, self.index))
        return temp


    def get_high_critical_threshold_by_bmc(self):
        """
        Retrieves the high critical threshold temperature of thermal
        Returns:
            A float number, the high critical threshold temperature of thermal in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """

        temp = 0
        if self.index == 0:
            temp = self.__get_bmc_high_critical_threshold("mb_air.in.tmp0")
        elif self.index == 1:
            temp = self.__get_bmc_high_critical_threshold("mb_air.out.tmp0")
        elif self.index == 2:
            temp = self.__get_bmc_high_critical_threshold("mb_tmp411.bf.tmp")
        elif self.index == 3:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc_high_critical_threshold(str_tmp) 
        elif self.index == 4:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc_high_critical_threshold(str_tmp) 
        elif self.index == 5:
            temp = self.__get_temp("temp1_crit")  
        elif self.index == 6:
            temp = self.__get_temp("temp2_crit") 
        elif self.index == 7:
            temp = self.__get_temp("temp3_crit")
            
        #print("#########thermal get_high_critical_threshold temp:%s index:%s" % (temp, self.index))
        return temp
		
    def get_low_threshold_by_bmc(self):
        """
        Retrieves the low threshold temperature of thermal
        Returns:
            A float number, the low threshold temperature of thermal in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """
        temp = 0
        if self.index == 0:
            temp = self.__get_bmc_low_threshold("mb_air.in.tmp0")
        elif self.index == 1:
            temp = self.__get_bmc_low_threshold("mb_air.out.tmp0")
        elif self.index == 2:
            temp = self.__get_bmc_low_threshold("mb_tmp411.bf.tmp")
        elif self.index == 3:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc_low_threshold(str_tmp)   
        elif self.index == 4:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc_low_threshold(str_tmp)   
        #print("#########thermal get_low_threshold temp:%s index:%s" % (temp, self.index))
        return temp
    def get_low_critical_threshold_by_bmc(self):
        """
        Retrieves the low critical threshold temperature of thermal
        Returns:
            A float number, the low critical threshold temperature of thermal in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """
        temp = 0
        if self.index == 0:
            temp = self.__get_bmc_low_critical_threshold("mb_air.in.tmp0")
        elif self.index == 1:
            temp = self.__get_bmc_low_critical_threshold("mb_air.out.tmp0")
        elif self.index == 2:
            temp = self.__get_bmc_low_critical_threshold("mb_tmp411.bf.tmp")
        elif self.index == 3:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc_low_critical_threshold(str_tmp)    
        elif self.index == 4:
            str_pwr_tmp = 'pwr{0}.tmp'
            str_tmp = str_pwr_tmp.format(self.index - 3 + self.psu_start_index)
            temp = self.__get_bmc_low_critical_threshold(str_tmp) 
        #print("#########thermal get_low_critical_threshold temp:%s index:%s" % (temp, self.index))
        return temp

    def get_psu_presence(self, psu_index):  
        """
        Retrieves the presence of the PSU
        Returns:
            bool: True if PSU is present, False if not
        """ 
        presence = 0  
        psu_presence_path = self.BASE_CPLD1_PATH + "psu1_presence" 
      
        if psu_index == 0:    
            psu_presence_path = self.BASE_CPLD1_PATH + "psu1_presence"     
        elif psu_index == 1:
            psu_presence_path = self.BASE_CPLD1_PATH + "psu2_presence"                 
        else: 
            print("unkown index[%s] for get_presence" % self.index) 
            

        val = self.__read_txt_file(psu_presence_path)

            
        if val == "1":
            #DBG_PRINT(" return True get_presence for self.index:%s psu_presence_path:%s content:%s" % (self.index, psu_presence_path, val))
            return True        
        else: 
            #DBG_PRINT("return False get_presence for self.index:%s psu_presence_path:%s content:%s" % (self.index, psu_presence_path, val))        
            return False  

    def _get_temperature_psu_by_come(self, psu_index):
        """
        Retrieves present electric current supplied by PSU
        Returns:
            A float number, the electric current in amperes, e.g 15.4
        """
        
        psu_data_path = self.BASE_CRPS0_PATH + "temp_input" 
      
        if psu_index == 0:    
            psu_data_path = self.BASE_CRPS0_PATH + "temp_input"     
        elif psu_index == 1:
            psu_data_path = self.BASE_CRPS1_PATH + "temp_input"                 
        else: 
            print("unkown index[%s] for get_presence" % self.index) 

        presence = self.get_psu_presence(psu_index) 
        if presence == False:
            DBG_PRINT("get_temperature for not present psu_index:%s psu_data_path:%s" % (psu_index, psu_data_path))        
            return float(0)            

        val = self.__read_txt_file(psu_data_path)

        #DBG_PRINT("get_current for self.index:%s psu_data_path:%s val:%s" % (self.index, psu_data_path, val))        
       

        return float(val) 

    def _get_temperature_psu(self, psu_index):
        return self._get_temperature_psu_by_come(psu_index)

    def get_temperature(self):
        """
        Retrieves current temperature reading from thermal
        Returns:
            A float number of current temperature in Celsius up to nearest thousandth
            of one degree Celsius, e.g. 30.125
        """
        
     
        temp = 0
        
        if self.index == 0:
            temp = self.__get_bmc("mb_air.in.tmp0")
        elif self.index == 1:
            temp = self.__get_bmc("mb_air.out.tmp0")
        elif self.index == 2:
            temp = self.__get_bmc("mb_tmp411.bf.tmp")
        elif self.index == 3:
            temp = self._get_temperature_psu(0) 
        elif self.index == 4:
            temp = self._get_temperature_psu(1)
        elif self.index == 5:
            temp = self.__get_temp("temp1_input")  
        elif self.index == 6:
            temp = self.__get_temp("temp2_input") 
        elif self.index == 7:
            temp = self.__get_temp("temp3_input")           
            



        #print("#########thermal get_temperature temp:%s index:%s" % (temp, self.index))
        return temp
        

    def get_high_threshold(self):
        """
        Retrieves the high threshold temperature of thermal
        Returns:
            A float number, the high threshold temperature of thermal in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """

        temp = 0     
        
        if self.index == 0:
            threshold_list = threshold_dict['mb_air.in.tmp0']
            temp = float(threshold_list[3])
        elif self.index == 1:
            threshold_list = threshold_dict['mb_air.out.tmp0']
            temp = float(threshold_list[3])
        elif self.index == 2:
            threshold_list = threshold_dict['mb_tmp411.bf.tmp']
            temp = float(threshold_list[3])
        elif self.index == 3:
            threshold_list = threshold_dict['pwr1.tmp']
            temp = float(threshold_list[3])    
        elif self.index == 4:
            threshold_list = threshold_dict['pwr2.tmp']
            temp = float(threshold_list[3]) 
        elif self.index == 5:
            temp = self.__get_temp("temp1_max")  
        elif self.index == 6:
            temp = self.__get_temp("temp2_max") 
        elif self.index == 7:
            temp = self.__get_temp("temp3_max") 
            
        #print("#########thermal get_high_threshold temp:%s index:%s" % (temp, self.index))
        return temp
        

    def get_high_critical_threshold(self):
        """
        Retrieves the high critical threshold temperature of thermal
        Returns:
            A float number, the high critical threshold temperature of thermal in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """

        temp = 0
        if self.index == 0:
            threshold_list = threshold_dict['mb_air.in.tmp0']
            temp = float(threshold_list[5])
        elif self.index == 1:
            threshold_list = threshold_dict['mb_air.out.tmp0']
            temp = float(threshold_list[5])
        elif self.index == 2:
            threshold_list = threshold_dict['mb_tmp411.bf.tmp']
            temp = float(threshold_list[5])
        elif self.index == 3:
            threshold_list = threshold_dict['pwr1.tmp']
            temp = float(threshold_list[5])    
        elif self.index == 4:
            threshold_list = threshold_dict['pwr2.tmp']
            temp = float(threshold_list[5]) 
        elif self.index == 5:
            temp = self.__get_temp("temp1_crit")  
        elif self.index == 6:
            temp = self.__get_temp("temp2_crit") 
        elif self.index == 7:
            temp = self.__get_temp("temp3_crit")
            
        #print("#########thermal get_high_critical_threshold temp:%s index:%s" % (temp, self.index))
        return temp
		
    def get_low_threshold(self):
        """
        Retrieves the low threshold temperature of thermal
        Returns:
            A float number, the low threshold temperature of thermal in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """
        temp = 0
        if self.index == 0:
            threshold_list = threshold_dict['mb_air.in.tmp0']
            temp = float(threshold_list[1])
        elif self.index == 1:
            threshold_list = threshold_dict['mb_air.out.tmp0']
            temp = float(threshold_list[1])
        elif self.index == 2:
            threshold_list = threshold_dict['mb_tmp411.bf.tmp']
            temp = float(threshold_list[1])
        elif self.index == 3:
            threshold_list = threshold_dict['pwr1.tmp']
            temp = float(threshold_list[1])    
        elif self.index == 4:
            threshold_list = threshold_dict['pwr2.tmp']
            temp = float(threshold_list[1]) 
            
        #print("#########thermal get_low_threshold temp:%s index:%s" % (temp, self.index))
        return temp
        
    def get_low_critical_threshold(self):
        """
        Retrieves the low critical threshold temperature of thermal
        Returns:
            A float number, the low critical threshold temperature of thermal in Celsius
            up to nearest thousandth of one degree Celsius, e.g. 30.125
        """
        temp = 0
        if self.index == 0:
            threshold_list = threshold_dict['mb_air.in.tmp0']
            temp = float(threshold_list[0])
        elif self.index == 1:
            threshold_list = threshold_dict['mb_air.out.tmp0']
            temp = float(threshold_list[0])
        elif self.index == 2:
            threshold_list = threshold_dict['mb_tmp411.bf.tmp']
            temp = float(threshold_list[0])
        elif self.index == 3:
            threshold_list = threshold_dict['pwr1.tmp']
            temp = float(threshold_list[0])    
        elif self.index == 4:
            threshold_list = threshold_dict['pwr2.tmp']
            temp = float(threshold_list[0]) 

            
        #print("#########thermal get_low_critical_threshold temp:%s index:%s" % (temp, self.index))
        return temp
        
    def set_high_threshold(self, temperature):
        """
        Sets the high threshold temperature of thermal
        Args :
            temperature: A float number up to nearest thousandth of one degree Celsius,
            e.g. 30.125
        Returns:
            A boolean, True if threshold is set successfully, False if not
        """


        return True

    def get_name(self):
        """
        Retrieves the name of the thermal device
            Returns:
            string: The name of the thermal device
        """
        return self.THERMAL_NAME_LIST[self.index]

    def get_presence(self):
        """
        Retrieves the presence of the Thermal
        Returns:
            bool: True if Thermal is present, False if not
        """
        
        return True
        

    def get_status(self):
        """
        Retrieves the operational status of the device
        Returns:
            A boolean value, True if device is operating properly, False if not
        """
        return True


__all__ = [
    'platform_sensors',
    'platform_fancontrol',
]
